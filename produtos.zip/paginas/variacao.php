<?php if ($vet[1] == 'excluir'){
    $sql = "DELETE FROM variacoes WHERE id = '".$vet[2]."'";
    mysqli_query($con, $sql);
    ?>
    <script>
        alert('Variação excluída com sucesso!');
        location.href="<?=URL?>variacao";
    </script>
    <?php
}
elseif ($vet[1] == 'cadastrar'){
    if ($_REQUEST['nome']){
        $sql = "SELECT * FROM variacoes WHERE nome = '".$_REQUEST['nome']."' AND idPai = '".$_REQUEST['variacaoPai']."'";
        $query = mysqli_query($con, $sql);
        if (!mysqli_num_rows($query)){
            $sql = "INSERT INTO variacoes (nome, idPai) VALUES ('".$_REQUEST['nome']."', '".$_REQUEST['variacaoPai']."')";
            mysqli_query($con, $sql);
            ?>
            <script>
                alert('Variação cadastrada com sucesso!');
                location.href="<?=URL?>variacao";
            </script>
            <?php
        }
        else{
            ?>
            <script>
                alert('Já existe essa variação cadastrada! Tente outra!');
                location.href="<?=URL?>variacao/cadastrar";
            </script>
            <?php
        }
    } else{?>
<div class="content-wrapper">
        <section class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-4">
                        <h1>Variações</h1>
                    </div>
                    <div class="col-sm-4">
                        <button class="btn btn-primary" data-toggle="modal" data-target="#modalCadastro" onclick=location.href="<?=URL?>variacao">&laquo; Voltar</button>
                    </div>
                    <div class="col-sm-4">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="<?=URL?>">Home</a></li>
                            <li class="breadcrumb-item">Cadastros</li>
                            <li class="breadcrumb-item active"><a href="<?=URL?>variacao">Variações</a></li>
                        </ol>
                    </div>
                </div>
            </div><!-- /.container-fluid -->
        </section>
<div class="modal-content">
<div class="modal-header">
    <h5 class="modal-title" id="exampleModalLabel">Cadastro de Variação</h5>
</div>
<form id="cadastroUsuario" method="post" action="">
    <div class="modal-body">
        <input type="hidden" name="idUserCadastro" id="idUserCadastro" value="<?=$_SESSION['user']['id']?>">
        <label for="variacaoPai">Variação Pai: </label>
        <select name="variacaoPai" id="variacaoPai" class="form-control">
            <option value="">Selecione a variação abaixo corretamente ou deixe em branco caso essa seja uma variação pai...</option>
            <?php foreach ($variacao as $key => $value){
            if (!$value->idPai){?>
            <option value="<?=$value->id?>"><?=$value->nome?></option>
            <?php } }?>
        </select>
        <label for="nome">Nome: </label>
        <input type="text" name="nome" id="nome" value="" required class="form-control">
    </div>
    <div class="modal-footer">
        <button type="submit" class="btn btn-primary">Cadastrar</button>
        <button type="button" class="btn btn-secondary" onclick="location.href='<?=URL?>variacao'">&laquo; Voltar</button>
    </div>
</form>
</div>
</div>
</div>
<?php
    }
}
elseif ($vet[1] == 'editar'){
    if ($_REQUEST['nome']){
        $sql = "SELECT * FROM variacoes WHERE nome = '".$_REQUEST['nome']."' AND idPai = '".$_REQUEST['variacaoPai']."' AND id != '".$_REQUEST['id']."'";
        $query = mysqli_query($con, $sql);
        if (!mysqli_num_rows($query)){
            $sql = "UPDATE variacoes SET nome = '".$_REQUEST['nome']."', idPai = '".$_REQUEST['variacaoPai']."' WHERE id = '".$_REQUEST['id']."'";
            mysqli_query($con, $sql);
            ?>
            <script>
                alert('Variação editada com sucesso!');
                location.href="<?=URL?>variacao";
            </script>
            <?php
        }
        else{
            ?>
            <script>
                alert('Já existe essa variação cadastrada! Tente outra!');
                location.href="<?=URL?>variacao/cadastrar";
            </script>
            <?php
        }
    } else{
        $sql = "SELECT * FROM variacoes WHERE id = '".$vet[2]."'";
        $query = mysqli_query($con, $sql);
        if (!mysqli_num_rows($query)){
            ?>
            <script>
                alert('Não foi encontrada a variação pesquisada! Tente novamente!');
                location.href="<?=URL?>variacao";
            </script>
            <?php
        }
        else{
            $row = mysqli_fetch_object($query);
        ?>
<div class="content-wrapper">
        <section class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-4">
                        <h1>Variações</h1>
                    </div>
                    <div class="col-sm-4">
                        <button class="btn btn-primary" data-toggle="modal" data-target="#modalCadastro" onclick=location.href="<?=URL?>variacao">&laquo; Voltar</button>
                    </div>
                    <div class="col-sm-4">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="<?=URL?>">Home</a></li>
                            <li class="breadcrumb-item">Cadastros</li>
                            <li class="breadcrumb-item active"><a href="<?=URL?>variacao">Variações</a></li>
                        </ol>
                    </div>
                </div>
            </div><!-- /.container-fluid -->
        </section>
<div class="modal-content">
<div class="modal-header">
    <h5 class="modal-title" id="exampleModalLabel">Edição de Variação</h5>
</div>
<form  method="post" action="">
    <div class="modal-body">
        <input type="hidden" name="id" id="id" value="<?=$row->id?>">
        <label for="variacaoPai">Variação Pai: </label>
        <select name="variacaoPai" id="variacaoPai" class="form-control">
            <option value="">Selecione a variação abaixo corretamente ou deixe em branco caso essa seja uma variação pai...</option>
            <?php foreach ($variacao as $key => $value){
            if (!$value->idPai){?>
            <option value="<?=$value->id?>"<?php if ($row->idPai == $value->id){?> selected<?php }?>><?=$value->nome?></option>
            <?php } }?>
        </select>
        <label for="nome">Nome: </label>
        <input type="text" name="nome" id="nome" value="<?=$row->nome?>" required class="form-control">
    </div>
    <div class="modal-footer">
        <button type="submit" class="btn btn-primary">Editar</button>
        <button type="button" class="btn btn-secondary" onclick="location.href='<?=URL?>variacao'">&laquo; Voltar</button>
    </div>
</form>
</div>
</div>
</div>
<?php
        }
    }
}
elseif ($vet[1] == 'visuailzar'){
        $sql = "SELECT a.*, b.nome AS nomePai FROM variacoes a LEFT JOIN variacoes b ON (a.idPai = b.id) WHERE a.id = '".$vet[2]."'";
        $query = mysqli_query($con, $sql);
        if (!mysqli_num_rows($query)){
            ?>
            <script>
                alert('Não foi encontrada a variação pesquisada! Tente novamente!');
                location.href="<?=URL?>variacao";
            </script>
            <?php
        }
        else{
            $row = mysqli_fetch_object($query);
        ?>
<div class="content-wrapper">
        <section class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-4">
                        <h1>Variações</h1>
                    </div>
                    <div class="col-sm-4">
                        <button class="btn btn-primary" data-toggle="modal" data-target="#modalCadastro" onclick=location.href="<?=URL?>variacao">&laquo; Voltar</button>
                    </div>
                    <div class="col-sm-4">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="<?=URL?>">Home</a></li>
                            <li class="breadcrumb-item">Cadastros</li>
                            <li class="breadcrumb-item active"><a href="<?=URL?>variacao">Variações</a></li>
                        </ol>
                    </div>
                </div>
            </div><!-- /.container-fluid -->
        </section>
<div class="modal-content">
<div class="modal-header">
    <h5 class="modal-title" id="exampleModalLabel">Visualização de Variação</h5>
</div>
<form  method="post" action="">
    <div class="modal-body">
        <input type="hidden" name="id" id="id" value="<?=$row->id?>">
        <label for="variacaoPai">Variação Pai: </label> <?=($row->nomePai) ? $row->nomePai : "-"?><br>
        <label for="nome">Nome: </label> <?=$row->nome?>
    </div>
    <div class="modal-footer">
        <button type="button" class="btn btn-secondary" onclick="location.href='<?=URL?>variacao'">&laquo; Voltar</button>
    </div>
</form>
</div>
</div>
</div>
<?php
    }
}
else{
    ?>
<div class="content-wrapper">
        <section class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-4">
                        <h1>Variações</h1>
                    </div>
                    <div class="col-sm-4">
                        <button class="btn btn-primary" data-toggle="modal" data-target="#modalCadastro" onclick=location.href="<?=URL?>variacao/cadastrar">Criar Novo</button>
                    </div>
                    <div class="col-sm-4">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="<?=URL?>">Home</a></li>
                            <li class="breadcrumb-item">Cadastros</li>
                            <li class="breadcrumb-item active"><a href="<?=URL?>variacao">Variações</a></li>
                        </ol>
                    </div>
                </div>
            </div><!-- /.container-fluid -->
        </section>
<div class="my-3 p-3 bg-white rounded shadow-sm">
    <div class="media text-muted pt-3">
        <h6 style="cursor: pointer" onclick="abreFecha('filtro')">Filtro</h6>
    </div>
    <div class="media text-muted pt-3" id="filtro" style="display:none">
    <form name="filtro" action="" method="post">
        <div style="width:100%">
            <label for="nomeFiltro">Por Nome: </label>
            <input type="text" class="form-control" id="nomeFiltro" name="nomeFiltro" style="width:100%" value="<?=$_REQUEST['nomeFiltro']?>">
        </div>
        <button type="submit" class="btn btn-primary">Filtrar</button>
    </div>
    </form>
    
    <div class="media text-muted pt-3" id="conteudo">
        <?php if (count($variacao)){?>
        <table id="example2" class="table table-bordered table-hover">
            <thead>
                <tr>
                    <th style="padding:5px">ID</th>
                    <th style="padding:5px">Nome</th>
                    <th style="padding:5px">Ações</th>
                </tr>
            </thead>
            <tbody>
            <?php foreach ($variacao as $key => $value){?>
                <tr>
                    <td style="padding:5px"><?=$value->id?></td>
                    <td style="padding:5px"><?=($value->nomePai) ? $value->nomePai." - " : ""?><?=$value->nome?></td>
                    <td style="padding:5px">
                         <a href="<?=URL?>variacao/visuailzar/<?=$value->id?>"><img src="<?=URL?>img/visualizar.svg" width="20"></a>
                         <a href="<?=URL?>variacao/editar/<?=$value->id?>"><img src="<?=URL?>img/editar.png" width="20"></a>
                        <a style="cursor:pointer" onclick=excluirVariacao("<?=$value->id?>","<?=URL?>")><img src="<?=URL?>img/excluir.png" width="20"></a>
                    </td>

                </tr>
            <?php }?>
            </tbody>
        </table>
        <?php } else{ ?><div class="btn btn-danger">Sem nenhum produto encontrado!</div><?php
        }?>
    </div>
</div>
    </div>
    <?php }?>