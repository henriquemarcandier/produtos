<?php
require_once('../connect.php');
error_reporting('1');
ini_set('display_erros', 'on');
$sql = "SELECT a.*, b.valor, b.promocao, b.validadePromocao, b.nome AS nameItem, b.id AS idItem, b.estoque, c.nome as nomeTipoVariacao1, d.nome AS nomeTipoVariacao2 FROM produtos a INNER JOIN produtos_itens b ON (a.id = b.idProduto) LEFT JOIN variacoes c ON (b.idTipoVariacao1 = c.id) LEFT JOIN variacoes d ON (b.idTipoVariacao2 = d.id)";
if ($_REQUEST['nomeFiltro']){
    $sql .= " WHERE a.nome LIKE '%".$_REQUEST['nomeFiltro']."%' OR a.descricao LIKE '%".$_REQUEST['nomeFiltro']."%' OR a.sku LIKE '%".$_REQUEST['nomeFiltro']."%' OR a.id LIKE '%".$_REQUEST['nomeFiltro']."%' OR b.valor LIKE '%".$_REQUEST['nomeFiltro']."%' OR b.promocao LIKE '%".$_REQUEST['nomeFiltro']."%'";
}
$sql .= " ORDER BY a.id ASC";
$query = mysqli_query($con, $sql);
$arquivo = ('ID do Produto;Nome;SKU;Variação 1;Variação 2;Imagem;ID do Item;Tipo Variação 1;Tipo Variação 2;Nome do Item;Valor;Promoção;Validade da Promoção;Estoque;')."\r\n";
if (mysqli_num_rows($query)){
    while($value = mysqli_fetch_object($query)){
        $vet2 = explode('-', $value->validadePromocao);
        $value->validadePromocao = $vet2[2]."/".$vet2[1]."/".$vet2[0];
        $sql = "SELECT b.nome, b.id FROM produtos_variacoes a INNER JOIN variacoes b ON (a.idVariacao = b.id) WHERE a.idProduto = '".$value->id."'";
        $query2 = mysqli_query($con, $sql);
        if (file_exists(DIRETORIO."img/produtos/".$value->id."/produto.jpg")){
            $img = URL."img/produtos/".$value->id."/produto.jpg";
        }
        elseif (file_exists(DIRETORIO."img/produtos/".$value->id."/produto.jpeg")){
            $img = URL."img/produtos/".$value->id."/produto.jpeg";
        }
        elseif (file_exists(DIRETORIO."img/produtos/".$value->id."/produto.gif")){
            $img = URL."img/produtos/".$value->id."/produto.gif";
        }
        elseif (file_exists(DIRETORIO."img/produtos/".$value->id."/produto.png")){
            $img = URL."img/produtos/".$value->id."/produto.png";
        }
        elseif (file_exists(DIRETORIO."img/produtos/".$value->id."/produto.bmp")){
            $img = URL."img/produtos/".$value->id."/produto.bmp";
        }
        elseif (file_exists(DIRETORIO."img/produtos/".$value->id."/produto.svg")){
            $img = URL."img/produtos/".$value->id."/produto.svg";
        }
        elseif (file_exists(DIRETORIO."img/produtos/".$value->id."/produto.webp")){
            $img = URL."img/produtos/".$value->id."/produto.webp";
        }
        else{
            $img = URL."img/noFoto1.gif";
        }
        $arquivo .= $value->id.";".$value->nome.";".$value->sku.";";
        if (mysqli_num_rows($query2)){
            $estaNo = mysqli_num_rows($query2);
            while ($row2 = mysqli_fetch_object($query2)){
                $arquivo .= $row2->nome.";";
            }
            if ($estaNo == 1){
                $arquivo .= ";";
            }
        }
        else{
            $arquivo .= ";;";
        }
        $arquivo .= $img.";".$value->idItem.";".$value->nomeTipoVariacao1.";".$value->nomeTipoVariacao2.";".$value->nameItem.";".$value->valor.";".$value->promocao.";".$value->validadePromocao.";".$value->estoque."\r\n";
    }
}
$fp = fopen(DIRETORIO_SITE."produtos.csv", "w+");
fwrite($fp, $arquivo);
fclose($fp);

$fp = fopen(DIRETORIO_SITE."produtos.csv", "r");
header('Content-type: text/csv');
header('Content-Disposition: attachment; filename=produtos'.date('Y-m-d-H-i-s').'.csv');

while(!feof ($fp)) {

    echo fgets($fp); //LENDO A LINHA
}
fclose($fp);
unlink(DIRETORIO_SITE."produtos.csv");
?>