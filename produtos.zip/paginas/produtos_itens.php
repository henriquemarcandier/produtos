<?php 
require_once('../connect.php');
if ($_REQUEST['valor']){
    $_REQUEST['valor'] = str_replace('.', '', $_REQUEST['valor']);
    $_REQUEST['valor'] = str_replace(',', '.', $_REQUEST['valor']);
    $_REQUEST['promocao'] = str_replace('.', '', $_REQUEST['promocao']);
    $_REQUEST['promocao'] = str_replace(',', '.', $_REQUEST['promocao']);
    if (!$_REQUEST['idItem']){
        $sql = "SELECT * FROM produtos_itens WHERE idProduto = '".$_REQUEST['idProduto']."' AND idTipoVariacao1 = '".$_REQUEST['idTipoVariacao1']."' AND idTipoVariacao2 = '".$_REQUEST['idTipoVariacao2']."'";
        $query = mysqli_query($con, $sql);
        if (mysqli_num_rows($query)){
            ?>
            <script>
                alert('Esses tipos de variações já estão cadastradas nesse produto!');
                location.href="<?=URL?>paginas/produtos_itens.php?id=<?=$_REQUEST['idProduto']?>";
            </script>
            <?php
        }
        else{
            $sql = "INSERT INTO produtos_itens (idProduto, idTipoVariacao1, idTipoVariacao2, nome, descricao, estoque, valor, promocao, validadePromocao) 
            VALUES ('".$_REQUEST['idProduto']."', '".$_REQUEST['idTipoVariacao1']."', '".$_REQUEST['idTipoVariacao2']."', '".$_REQUEST['nome']."', '".$_REQUEST['descricao']."', '".$_REQUEST['estoque']."', '".$_REQUEST['valor']."', '".$_REQUEST['promocao']."', '".$_REQUEST['validadePromocao']."')";
            mysqli_query($con, $sql);
            ?>
            <script>
                alert('Item de Produto cadastrado com sucesso!');
                location.href="<?=URL?>paginas/produtos_itens.php?id=<?=$_REQUEST['idProduto']?>";
            </script>
            <?php
        }
    }
    else{
        $sql = "SELECT * FROM produtos_itens WHERE id != '".$_REQUEST['idItem']."' AND idProduto = '".$_REQUEST['idProduto']."' AND idTipoVariacao1 = '".$_REQUEST['idTipoVariacao1']."' AND idTipoVariacao2 = '".$_REQUEST['idTipoVariacao2']."'";
        $query = mysqli_query($con, $sql);
        if (mysqli_num_rows($query)){
            ?>
            <script>
                alert('Esses tipos de variações já estão cadastradas nesse produto!');
                location.href="<?=URL?>paginas/produtos_itens.php?id=<?=$_REQUEST['idProduto']?>";
            </script>
            <?php
        }
        else{
            $sql = "UPDATE produtos_itens 
            SET idProduto = '".$_REQUEST['idProduto']."', idTipoVariacao1 = '".$_REQUEST['idTipoVariacao1']."', idTipoVariacao2 = '".$_REQUEST['idTipoVariacao2']."', nome = '".$_REQUEST['nome']."', descricao = '".$_REQUEST['descricao']."', estoque = '".$_REQUEST['estoque']."', valor = '".$_REQUEST['valor']."', promocao = '".$_REQUEST['promocao']."', validadePromocao = '".$_REQUEST['validadePromocao']."'
            WHERE id = '".$_REQUEST['idItem']."'";
            mysqli_query($con, $sql);
            ?>
            <script>
                alert('Item de Produto atualizado com sucesso!');
                location.href="<?=URL?>paginas/produtos_itens.php?id=<?=$_REQUEST['idProduto']?>";
            </script>
            <?php
        }
    }
}
elseif($_REQUEST['excluir']){
    $sql = "DELETE FROM produtos_itens WHERE id = '".$_REQUEST['idItem']."'";
    mysqli_query($con, $sql);
    ?>
    <script>
        alert('Item do produto excluído com sucesso!');
        location.href="<?=URL?>paginas/produtos_itens.php?id=<?=$_REQUEST['id']?>";
    </script>
    <?php
}
else{
$sql = "SELECT a.*
FROM produtos_itens a
WHERE a.idProduto = '".$_REQUEST['id']."'";
$query = mysqli_query($con, $sql);
?><!doctype html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Teste do Henrique Marcandier</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <link rel="stylesheet" href="<?php echo URL?>img/style.css">
    <link rel="shortcut icon" href="<?php echo URL?>img/favicon.ico">
</head>
<body>
<div style="float:left; width:35%; top:0px; position:absolute;" id="itensVendaProduto">
<?php
while ($row = mysqli_fetch_array($query)) {
    ?>
    <div style="width:100%; padding:10px" id="itemVenda<?php echo $row['id']?>" onmouseover="this.style.backgroundColor='#F7F7F7'" onmouseout="this.style.backgroundColor='#FFFFFF'"><?php echo ($row['nome'])?>
    <img src="<?php echo URL?>img/editar.png" width="20" style="cursor:pointer" onclick="location.href='<?=URL?>paginas/produtos_itens.php?editar=1&id=<?=$_REQUEST['id']?>&idItem=<?=$row['id']?>'"> <img src="<?=URL?>img/excluir.png" width="20" style="cursor:pointer" onclick="excluirItem('<?php echo $row['id']?>', '<?php echo URL?>', '<?php echo $row['idProduto']?>')"></div>
    <?php
}
?>
</div>
<?php 
if ($_REQUEST['editar']){
    $sql = "SELECT * FROM produtos_itens WHERE id = '".$_REQUEST['idItem']."' AND idProduto = '".$_REQUEST['id']."'";
    $queryE = mysqli_query($con, $sql);
    $rowE = mysqli_fetch_object($queryE);
}?>
<div style="float:left; width:60%; top:0px; position:absolute; left:35%">
    <form class="js-validate" id="formItemVenda" method="post">
        <h3 style="text-align:center;">Cadastro de Item do Produto</h3>
        <input type="hidden" value="<?=URL?>" name="url" id="url">
        <input type="hidden" value="<?=$_REQUEST['id']?>" name="idProduto" id="idProduto">
        <input type="hidden" value="<?=$rowE->id?>" name="idItem" id="idItem">
        <?php 
        $sql = "SELECT b.nome, b.id FROM produtos_variacoes a INNER JOIN variacoes b ON (a.idVariacao = b.id) WHERE a.idProduto = '".$_REQUEST['id']."'";
        $query2 = mysqli_query($con, $sql);
        $i = 1;
        if (mysqli_num_rows($query2)){
            while ($row2 = mysqli_fetch_object($query2)){
                ?><label for="idTipoVariacao<?=$i?>"><?=$row2->nome?>: </label><select name="idTipoVariacao<?=$i?>" id="idTipoVariacao<?=$i?>" class="form-control" required>
                    <option value="">Selecione o tipo de variação abaixo...</option>
                    <?php $sql = "SELECT * FROM variacoes WHERE idPai = '".$row2->id."'";
                    $query3 = mysqli_query($con, $sql);
                    if (mysqli_num_rows($query3)){
                        while ($row3 = mysqli_fetch_object($query3)){
                            ?><option value='<?=$row3->id?>'<?php if ($rowE->{"idTipoVariacao".$i} == $row3->id){?> selected<?php }?>><?=$row3->nome?></option><?php
                        }   
                    }?>
                </select><?php
                $i++;
            }
        }
        ?>
        <label for="nome">Nome: </label>
        <input type="text" name="nome" id="nome" class="form-control" value="<?=$rowE->nome?>" required>
        <label for="descricao">Descrição: </label>
        <textarea name="descricao" id="descricao" class="form-control"><?=$rowE->descricao?></textarea>
        <label for="valor">Valor: R$</label>
        <input type="text" name="valor" id="valor" class="form-control" onkeyup="mascaraValor(this.value, 'valor')" required value="<?=number_format($rowE->valor, 2, ',', '.')?>">
        <label for="promocao">Promoção: R$</label>
        <input type="text" name="promocao" id="promocao" class="form-control" onkeyup="mascaraValor(this.value, 'promocao')" value="<?=number_format($rowE->promocao, 2, ',', '.')?>">
        <label for="validadePromocao">Validade da Promoção</label>
        <input type="date" name="validadePromocao" id="validadePromocao" class="form-control" value="<?=$rowE->validadePromocao?>">
        <label for="estoque">Estoque</label>
        <input type="text" name="estoque" id="estoque" class="form-control" required value="<?=$rowE->estoque?>">
        <button type="submit" class="btn btn-primary">Cadastrar</button>
        <button type="button" class="btn btn-secondary" onclick="limparCampos()">Limpar Campos</button>
    </form>
<!-- jQuery -->
<script src="<?=URL?>plugins/jquery/jquery.min.js"></script>
<!-- jQuery UI 1.11.4 -->
<script src="<?=URL?>plugins/jquery-ui/jquery-ui.min.js"></script>
<!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->
<script>
    $.widget.bridge('uibutton', $.ui.button)
</script>
<!-- Bootstrap 4 -->
<script src="<?=URL?>plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- ChartJS -->
<script src="<?=URL?>plugins/chart.js/Chart.min.js"></script>
<!-- AdminLTE App -->
<script src="<?=URL?>dist/js/adminlte.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="<?=URL?>dist/js/demo.js"></script>
<script src="<?=URL?>dist/js/scripts.js"></script>
<script src="<?=URL?>ckeditor/ckeditor.js"></script>
<script>CKEDITOR.replace('descricao');</script>
</body>
</html>
<?php } ?>