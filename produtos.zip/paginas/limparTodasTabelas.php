<?php
$sql = "TRUNCATE produtos";
mysqli_query($con, $sql);
$sql = "TRUNCATE produtos_itens";
mysqli_query($con, $sql);
$sql = "TRUNCATE produtos_variacoes";
mysqli_query($con, $sql);
$sql = "TRUNCATE variacoes";
mysqli_query($con, $sql);
?>
<div class="content-wrapper">
        <section class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-12">
                        <h1>Todas as tabelas foram apagadas corretamente!</h1>
                        </div>
                    </div>
                </div>
            </div>
        </section>
</div>
?>