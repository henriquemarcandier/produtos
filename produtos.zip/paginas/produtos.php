<?php if ($vet[1] == 'excluir'){
    $sql = "DELETE FROM produtos WHERE id = '".$vet[2]."'";
    mysqli_query($con, $sql);
    $sql = "DELETE FROM produtos_itens WHERE idProduto = '".$vet[2]."'";
    mysqli_query($con, $sql);
    $sql = "DELETE FROM produtos_variacoes WHERE idProduto = '".$vet[2]."'";
    mysqli_query($con, $sql);
    @unlink(DIRETORIO."img/produtos/".$vet[2]."/produto.jpg");
    @unlink(DIRETORIO."img/produtos/".$vet[2]."/produto.jpeg");
    @unlink(DIRETORIO."img/produtos/".$vet[2]."/produto.gif");
    @unlink(DIRETORIO."img/produtos/".$vet[2]."/produto.png");
    @unlink(DIRETORIO."img/produtos/".$vet[2]."/produto.bmp");
    @unlink(DIRETORIO."img/produtos/".$vet[2]."/produto.svg");
    @unlink(DIRETORIO."img/produtos/".$vet[2]."/produto.webp");
    ?>
    <script>
        alert('Produto excluído com sucesso!');
        location.href="<?=URL?>produtos";
    </script>
    <?php
}
elseif ($vet[1] == 'excluirImg'){
    @unlink(DIRETORIO."img/produtos/".$vet[2]."/produto.jpg");
    @unlink(DIRETORIO."img/produtos/".$vet[2]."/produto.jpeg");
    @unlink(DIRETORIO."img/produtos/".$vet[2]."/produto.gif");
    @unlink(DIRETORIO."img/produtos/".$vet[2]."/produto.png");
    @unlink(DIRETORIO."img/produtos/".$vet[2]."/produto.bmp");
    @unlink(DIRETORIO."img/produtos/".$vet[2]."/produto.svg");
    @unlink(DIRETORIO."img/produtos/".$vet[2]."/produto.webp");
    ?>
    <script>
        alert('Imagem do produto excluída com sucesso!');
        location.href="<?=URL?>produtos/visualizar/<?=$vet[2]?>";
    </script>
    <?php
}
elseif($vet[1] == 'importar'){
    if (isset($_FILES['arquivo']['error']) && $_FILES['arquivo']['error'] == 0){
        if ($_REQUEST['limparCampos']){
            $sql = "TRUNCATE produtos";
            mysqli_query($con, $sql);
            $sql = "TRUNCATE produtos_itens";
            mysqli_query($con, $sql);
            $sql = "TRUNCATE produtos_variacoes";
            mysqli_query($con, $sql);
            $sql = "TRUNCATE variacoes";
            mysqli_query($con, $sql);
            $limpouCampos = 1;
        }
        if ( $_FILES['arquivo']['tmp_name'] ){        
            $file = fopen($_FILES['arquivo']['tmp_name'], 'r');
            $i = 0;
            while (($getData = fgetcsv($file, 10000, ",")) !== FALSE)
            {
                $vet2 = explode(';', $getData[0]);
                if ($i > 0){
                    $idProduto = $vet2[0];
                    $nome = $vet2[1];
                    $sku = $vet2[2];
                    $variacao1 = $vet2[3];
                    $variacao2 = $vet2[4];
                    $img = $vet2[5];
                    $idItem = $vet2[6];
                    $tipoVariacao1 = $vet2[7];
                    $tipoVariacao2 = $vet2[8];
                    $nomeItem = $vet2[9];
                    $valor = $vet2[10];
                    $promocao = $vet2[11];
                    $validadePromocao = $vet2[12];
                    $vet3 = explode("/", $validadePromocao);
                    $validadePromocao = $vet3[2]."-".$vet3[1]."-".$vet3[0];
                    $estoque = $vet2[13];
                    if ($variacao1){
                        $sql = "SELECT * FROM variacoes WHERE nome = '".$variacao1."' AND idPai = '0'";
                        $query = mysqli_query($con, $sql);
                        if (mysqli_num_rows($query)){
                            $row = mysqli_fetch_array($query);
                            $idVariacao1 = $row['id'];
                        }
                        else{
                            $sql = "INSERT INTO variacoes (nome, idPai) VALUES ('".$variacao1."', '0')";
                            mysqli_query($con, $sql);
                            $idVariacao1 = mysqli_insert_id($con);
                        }
                    }
                    else{
                        $idVariacao1 = 0;
                    }
                    if ($variacao2){
                        $sql = "SELECT * FROM variacoes WHERE nome = '".$variacao2."' AND idPai = '0'";
                        $query = mysqli_query($con, $sql);
                        if (mysqli_num_rows($query)){
                            $row = mysqli_fetch_array($query);
                            $idVariacao2 = $row['id'];
                        }
                        else{
                            $sql = "INSERT INTO variacoes (nome, idPai) VALUES ('".$variacao2."', '0')";
                            mysqli_query($con, $sql);
                            $idVariacao2 = mysqli_insert_id($con);
                        }
                    }
                    else{
                        $idVariacao2 = 0;
                    }
                    if ($tipoVariacao1){
                        $sql = "SELECT * FROM variacoes WHERE nome = '".$tipoVariacao1."' AND idPai = '".$idVariacao1."'";
                        $query = mysqli_query($con, $sql);
                        if (mysqli_num_rows($query)){
                            $row = mysqli_fetch_array($query);
                            $idTipoVariacao1 = $row['id'];
                        }
                        else{
                            $sql = "INSERT INTO variacoes (nome, idPai) VALUES ('".$tipoVariacao1."', '".$idVariacao1."')";
                            mysqli_query($con, $sql);
                            $idTipoVariacao1 = mysqli_insert_id($con);
                        }
                    }
                    else{
                        $idTipoVariacao1 = 0;
                    }
                    if ($tipoVariacao2){
                        $sql = "SELECT * FROM variacoes WHERE nome = '".$tipoVariacao2."' AND idPai = '".$idVariacao2."'";
                        $query = mysqli_query($con, $sql);
                        if (mysqli_num_rows($query)){
                            $row = mysqli_fetch_array($query);
                            $idTipoVariacao2 = $row['id'];
                        }
                        else{
                            $sql = "INSERT INTO variacoes (nome, idPai) VALUES ('".$tipoVariacao2."', '".$idVariacao2."')";
                            mysqli_query($con, $sql);
                            $idTipoVariacao2 = mysqli_insert_id($con);
                        }
                    }
                    else{
                        $idTipoVariacao2 = 0;
                    }
                    $sql = "SELECT * FROM produtos WHERE id = '".$idProduto."'";
                    $query4 = mysqli_query($con, $sql);
                    if (!mysqli_num_rows($query4)){
                        $sql = "INSERT INTO produtos (nome, sku) VALUES ('".$nome."', '".$sku."')";
                        mysqli_query($con, $sql);
                    }
                    if ($idVariacao1){
                        $sql = "SELECT * FROM produtos_variacoes WHERE idProduto = '".$idProduto."' AND idVariacao = '".$idVariacao1."'";
                        $query5 = mysqli_query($con, $sql);
                        if (!mysqli_num_rows($query5)){
                            $sql = "INSERT INTO produtos_variacoes(idProduto, idVariacao) VALUES ('".$idProduto."', '".$idVariacao1."')";
                            mysqli_query($con, $sql);
                        }
                    }
                    if ($idVariacao2){
                        $sql = "SELECT * FROM produtos_variacoes WHERE idProduto = '".$idProduto."' AND idVariacao = '".$idVariacao2."'";
                        $query6 = mysqli_query($con, $sql);
                        if (!mysqli_num_rows($query6)){
                            $sql = "INSERT INTO produtos_variacoes(idProduto, idVariacao) VALUES ('".$idProduto."', '".$idVariacao2."')";
                            mysqli_query($con, $sql);
                        }
                    }
                    $sql = "SELECT * FROM produtos_itens WHERE idProduto = '".$idProduto."' AND id = '".$idItem."'";
                    $query7 = mysqli_query($con, $sql);
                    if (!mysqli_num_rows($query7)){
                        $sql = "INSERT INTO produtos_itens (id, idProduto, idTipoVariacao1, idTipoVariacao2, nome, valor, promocao, validadePromocao, estoque)
                        VALUES ('".$idItem."', '".$idProduto."', '".$idTipoVariacao1."', '".$idTipoVariacao2."', '".$nomeItem."', '".$valor."', '".$promocao."', '".$validadePromocao."', '".$estoque."')";
                        mysqli_query($con, $sql);
                    }
                }
                $i++;
            }
        }
        ?><script>
            alert('Planilha importada comm sucesso!');
            location.href="<?=URL?>produtos";
        </script><?php 
    }
    else{
    ?>
    <div class="content-wrapper">
            <section class="content-header">
                <div class="container-fluid">
                    <div class="row mb-2">
                        <div class="col-sm-4">
                            <h1>Produtos</h1>
                        </div>
                        <div class="col-sm-4">
                            <button class="btn btn-primary" data-toggle="modal" data-target="#modalCadastro" onclick=location.href="<?=URL?>produtos">&laquo; Voltar</button>
                        </div>
                        <div class="col-sm-4">
                            <ol class="breadcrumb float-sm-right">
                                <li class="breadcrumb-item"><a href="<?=URL?>">Home</a></li>
                                <li class="breadcrumb-item">Cadastros</li>
                                <li class="breadcrumb-item active"><a href="<?=URL?>produtos">Produtos</a></li>
                            </ol>
                        </div>
                    </div>
                </div><!-- /.container-fluid -->
            </section>
    <div class="modal-content">
    <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Importação de Produto</h5>
    </div>
    <form id="cadastroUsuario" method="post" action="" enctype="multipart/form-data">
        <div class="modal-body">
            <label>Certifique de que o campo de limpar todos os registos das tabelas esteja correto.</label><br>
            <label for="arquivo">Arquivo: </label>
            <input type="file" name="arquivo" id="arquivo" value="" required class="form-control">
            <input type="checkbox" name="limparCampos" id="limparCampos" checked> <label for="limparCampos">Limpar todos os registros das tabelas antes da importação.</label>
        </div>
        <div class="modal-footer">
            <button type="submit" class="btn btn-primary">Importar</button>
            <button type="button" class="btn btn-secondary" onclick="location.href='<?=URL?>produtos'">&laquo; Voltar</button>
        </div>
    </form>
    </div>
    </div>
    </div><?php
    }
}
elseif ($vet[1] == 'cadastrar'){
    if ($_REQUEST['nome']){
        $sql = "SELECT * FROM produtos WHERE nome = '".$_REQUEST['nome']."'";
        $query = mysqli_query($con, $sql);
        if (!mysqli_num_rows($query)){
            $sql = "INSERT INTO produtos (nome, sku, descricao) VALUES ('".$_REQUEST['nome']."', '".$_REQUEST['sku']."', '".$_REQUEST['descricao']."')";
            mysqli_query($con, $sql);
            $idProduto = mysqli_insert_id($con);
            if ($_REQUEST['variacao1']){
                $sql = "INSERT INTO produtos_variacoes (idProduto, idVariacao) VALUES ('".$idProduto."', '".$_REQUEST['variacao1']."')";
                mysqli_query($con, $sql);
            }
            if ($_REQUEST['variacao2']){
                $sql = "INSERT INTO produtos_variacoes (idProduto, idVariacao) VALUES ('".$idProduto."', '".$_REQUEST['variacao2']."')";
                mysqli_query($con, $sql);
            }
            if ($_FILES['imagem']['error'] == 0){
                if (preg_match('/.jpg/', $_FILES['imagem']['name'])){
                    $tipo = ".jpg";
                } elseif (preg_match('/.jpeg/', $_FILES['imagem']['name'])){
                    $tipo = ".jpeg";
                } elseif (preg_match('/.gif/', $_FILES['imagem']['name'])){
                    $tipo = ".gif";
                } elseif (preg_match('/.png/', $_FILES['imagem']['name'])){
                    $tipo = ".png";
                } elseif (preg_match('/.bmp/', $_FILES['imagem']['name'])){
                    $tipo = ".bmp";
                } elseif (preg_match('/.svg/', $_FILES['imagem']['name'])){
                    $tipo = ".svg";
                } elseif (preg_match('/.webp/', $_FILES['imagem']['name'])){
                    $tipo = ".webp";
                }
                if ($tipo){
                    if (!file_exists(DIRETORIO."img/produtos/".$idProduto."/")){
                        mkdir(DIRETORIO."img/produtos/".$idProduto."/");
                        chmod(DIRETORIO."img/produtos/".$idProduto."/", 0777);
                    }
                    @unlink(DIRETORIO."img/produtos/".$idProduto."/produto.jpg");
                    @unlink(DIRETORIO."img/produtos/".$idProduto."/produto.jpeg");
                    @unlink(DIRETORIO."img/produtos/".$idProduto."/produto.gif");
                    @unlink(DIRETORIO."img/produtos/".$idProduto."/produto.png");
                    @unlink(DIRETORIO."img/produtos/".$idProduto."/produto.bmp");
                    @unlink(DIRETORIO."img/produtos/".$idProduto."/produto.svg");
                    @unlink(DIRETORIO."img/produtos/".$idProduto."/produto.webp");
                    copy($_FILES['imagem']['tmp_name'], DIRETORIO."img/produtos/".$idProduto."/produto".$tipo);
                }
            }
            ?>
            <script>
                alert('Produto cadastrado com sucesso!');
                location.href="<?=URL?>produtos";
            </script>
            <?php
        }
        else{
            ?>
            <script>
                alert('Já existe esse nome de produto cadastrado! Tente outro!');
                location.href="<?=URL?>produtos/cadastrar";
            </script>
            <?php
        }
    } else{?>
<div class="content-wrapper">
        <section class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-4">
                        <h1>Produtos</h1>
                    </div>
                    <div class="col-sm-4">
                        <button class="btn btn-primary" data-toggle="modal" data-target="#modalCadastro" onclick=location.href="<?=URL?>produtos">&laquo; Voltar</button>
                    </div>
                    <div class="col-sm-4">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="<?=URL?>">Home</a></li>
                            <li class="breadcrumb-item">Cadastros</li>
                            <li class="breadcrumb-item active"><a href="<?=URL?>produtos">Produtos</a></li>
                        </ol>
                    </div>
                </div>
            </div><!-- /.container-fluid -->
        </section>
<div class="modal-content">
<div class="modal-header">
    <h5 class="modal-title" id="exampleModalLabel">Cadastro de Produto</h5>
</div>
<form id="cadastroUsuario" method="post" action="" enctype="multipart/form-data">
    <div class="modal-body">
        <label>Obs: cadastre o produto depois o edite para cadastrar os seus ítens</label><br>
        <label for="nome">Nome: </label>
        <input type="text" name="nome" id="nome" value="" required class="form-control">
        <label for="nome">SKU: </label>
        <input type="text" name="sku" id="sku" value="" required class="form-control">
        <label for="descricao">Descrição: </label>
        <textarea name="descricao" id="descricao" value="" class="form-control"></textarea>
        <label for="variacao1">Variação 1: </label>
        <select name="variacao1" id="variacao1" class="form-control">
            <option value="">Selecione a variação abaixo se existir</option>
            <?php 
            foreach ($variacao as $key => $value){
                if (!$value->idPai){?>
                <option value="<?=$value->id?>"><?=$value->nome?></option>
                <?php }
            }?>
        </select>
        <label for="variacao2">Variação 2: </label>
        <select name="variacao2" id="variacao2" class="form-control">
            <option value="">Selecione a variação abaixo se existir</option>
            <?php 
            foreach ($variacao as $key => $value){
                if (!$value->idPai){?>
                <option value="<?=$value->id?>"><?=$value->nome?></option>
                <?php }
            }?>
        </select>
        <label for="imagem">Imagem: </label>
        <input type="file" name="imagem" id="imagem" value="" class="form-control">
    </div>
    <div class="modal-footer">
        <button type="submit" class="btn btn-primary">Cadastrar</button>
        <button type="button" class="btn btn-secondary" onclick="location.href='<?=URL?>produtos'">&laquo; Voltar</button>
    </div>
</form>
</div>
</div>
</div>
<?php
    }
}
elseif ($vet[1] == 'editar'){
    if ($_REQUEST['nome']){
        $sql = "SELECT * FROM produtos WHERE nome = '".$_REQUEST['nome']."' AND id != '".$_REQUEST['id']."'";
        $query = mysqli_query($con, $sql);
        if (!mysqli_num_rows($query)){
            $sql = "UPDATE produtos SET nome = '".$_REQUEST['nome']."', sku = '".$_REQUEST['sku']."', descricao = '".$_REQUEST['descricao']."' WHERE id = '".$_REQUEST['id']."'";
            mysqli_query($con, $sql);
            $sql ="DELETE FROM produtos_variacoes WHERE idProduto = '".$_REQUEST['id']."'";
            mysqli_query($con, $sql);
            if ($_REQUEST['variacao1']){
                $sql = "INSERT INTO produtos_variacoes (idProduto, idVariacao) VALUES ('".$_REQUEST['id']."', '".$_REQUEST['variacao1']."')";
                mysqli_query($con, $sql);
            }
            if ($_REQUEST['variacao2']){
                $sql = "INSERT INTO produtos_variacoes (idProduto, idVariacao) VALUES ('".$_REQUEST['id']."', '".$_REQUEST['variacao2']."')";
                mysqli_query($con, $sql);
            }
            $idProduto = $_REQUEST['id'];
            if ($_FILES['imagem']['error'] == 0){
                if (preg_match('/.jpg/', $_FILES['imagem']['name'])){
                    $tipo = ".jpg";
                } elseif (preg_match('/.jpeg/', $_FILES['imagem']['name'])){
                    $tipo = ".jpeg";
                } elseif (preg_match('/.gif/', $_FILES['imagem']['name'])){
                    $tipo = ".gif";
                } elseif (preg_match('/.png/', $_FILES['imagem']['name'])){
                    $tipo = ".png";
                } elseif (preg_match('/.bmp/', $_FILES['imagem']['name'])){
                    $tipo = ".bmp";
                } elseif (preg_match('/.svg/', $_FILES['imagem']['name'])){
                    $tipo = ".svg";
                } elseif (preg_match('/.webp/', $_FILES['imagem']['name'])){
                    $tipo = ".webp";
                }
                if ($tipo){
                    if (!file_exists(DIRETORIO."img/produtos/".$idProduto."/")){
                        mkdir(DIRETORIO."img/produtos/".$idProduto."/");
                        chmod(DIRETORIO."img/produtos/".$idProduto."/", 0777);
                    }
                    @unlink(DIRETORIO."img/produtos/".$idProduto."/produto.jpg");
                    @unlink(DIRETORIO."img/produtos/".$idProduto."/produto.jpeg");
                    @unlink(DIRETORIO."img/produtos/".$idProduto."/produto.gif");
                    @unlink(DIRETORIO."img/produtos/".$idProduto."/produto.png");
                    @unlink(DIRETORIO."img/produtos/".$idProduto."/produto.bmp");
                    @unlink(DIRETORIO."img/produtos/".$idProduto."/produto.svg");
                    @unlink(DIRETORIO."img/produtos/".$idProduto."/produto.webp");
                    copy($_FILES['imagem']['tmp_name'], DIRETORIO."img/produtos/".$idProduto."/produto".$tipo);
                }
            }
            ?>
            <script>
                alert('Produto editado com sucesso!');
                location.href="<?=URL?>produtos";
            </script>
            <?php
        }
        else{
            ?>
            <script>
                alert('Já existe esse produto cadastrado! Tente outro!');
                location.href="<?=URL?>produtos/editar/<?=$vet[2]?>";
            </script>
            <?php
        }
    } else{
        $sql = "SELECT * FROM produtos WHERE id = '".$vet[2]."'";
        $query = mysqli_query($con, $sql);
        if (!mysqli_num_rows($query)){
            ?>
            <script>
                alert('Não foi encontrada o produto pesquisado! Tente novamente!');
                location.href="<?=URL?>produtos";
            </script>
            <?php
        }
        else{
            $row = mysqli_fetch_object($query);
            $sql = "SELECT * FROM produtos_variacoes WHERE idProduto = '".$row->id."'";
            $query2 = mysqli_query($con, $sql);
            if (mysqli_num_rows($query2)){
                while ($row2 = mysqli_fetch_object($query2)){
                    $variacoesProduto[] = $row2->idVariacao;
                }
            }
        ?>
<div class="content-wrapper">
        <section class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-4">
                        <h1>Produtos</h1>
                    </div>
                    <div class="col-sm-4">
                        <button class="btn btn-primary" data-toggle="modal" data-target="#modalCadastro" onclick=location.href="<?=URL?>produtos">&laquo; Voltar</button>
                    </div>
                    <div class="col-sm-4">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="<?=URL?>">Home</a></li>
                            <li class="breadcrumb-item">Cadastros</li>
                            <li class="breadcrumb-item active"><a href="<?=URL?>produtos">Produtos</a></li>
                        </ol>
                    </div>
                </div>
            </div><!-- /.container-fluid -->
        </section>
<div class="modal-content">
<div class="modal-header">
    <h5 class="modal-title" id="exampleModalLabel">Edição de Produto</h5>
</div>
<form  method="post" action="" enctype="multipart/form-data">
    <button class="btn btn-primary" onclick="abreProdutos('dadosProduto'); return false;">Dados do Produto</button>
    <button class="btn btn-success" onclick="abreProdutos('itensProduto'); return false;">Ítens do Produto</button>
    <div class="modal-body" id="dadosProduto">
        <input type="hidden" name="id" id="id" value="<?=$row->id?>">
        <label for="nome">Nome: </label>
        <input type="text" name="nome" id="nome" value="<?=$row->nome?>" required class="form-control">
        <label for="nome">SKU: </label>
        <input type="text" name="sku" id="sku" value="<?=$row->sku?>" required class="form-control">
        <label for="descricao">Descrição: </label>
        <textarea name="descricao" id="descricao" class="form-control"><?=$row->descricao?></textarea>
        <label for="variacao1">Variação 1: </label>
        <select name="variacao1" id="variacao1" class="form-control">
            <option value="">Selecione a variação abaixo se existir</option>
            <?php 
            foreach ($variacao as $key => $value){
                if (!$value->idPai){?>
                <option value="<?=$value->id?>"<?php if ($value->id == $variacoesProduto[0]){?> selected<?php }?>><?=$value->nome?></option>
                <?php }
            }?>
        </select>
        <label for="variacao2">Variação 2: </label>
        <select name="variacao2" id="variacao2" class="form-control">
            <option value="">Selecione a variação abaixo se existir</option>
            <?php 
            foreach ($variacao as $key => $value){
                if (!$value->idPai){?>
                <option value="<?=$value->id?>"<?php if ($value->id == $variacoesProduto[1]){?> selected<?php }?>><?=$value->nome?></option>
                <?php }
            }?>
        </select>
        <label for="imagem">Imagem: </label>
        <input type="file" name="imagem" id="imagem" value="" class="form-control">
    </div>
    <div class="modal-body" id="itensProduto" style="display:none">
        <iframe src="<?=URL?>paginas/produtos_itens.php?id=<?=$row->id?>" width="100%" height="500"></iframe>
    </div>
    <div class="modal-footer">
        <span id="botaoEditar"><button type="submit" class="btn btn-primary">Editar</button></span>
        <button type="button" class="btn btn-secondary" onclick="location.href='<?=URL?>produtos'">&laquo; Voltar</button>
    </div>
</form>
</div>
</div>
</div>
<?php
        }
    }
}
elseif ($vet[1] == 'visuailzar'){
        $sql = "SELECT a.* FROM produtos a WHERE a.id = '".$vet[2]."'";
        $query = mysqli_query($con, $sql);
        if (!mysqli_num_rows($query)){
            ?>
            <script>
                alert('Não foi encontrada a Produtos pesquisada! Tente novamente!');
                location.href="<?=URL?>produtos";
            </script>
            <?php
        }
        else{
            $row = mysqli_fetch_object($query);
            $sql = "SELECT a.*, b.nome FROM produtos_variacoes a INNER JOIN variacoes b ON (a.idVariacao = b.id) WHERE a.idProduto = '".$row->id."'";
            $query2 = mysqli_query($con, $sql);
            if (mysqli_num_rows($query2)){
                while ($row2 = mysqli_fetch_object($query2)){
                    $produtos_variacoes[] = $row2;
                }
            }
        ?>
<div class="content-wrapper">
        <section class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-4">
                        <h1>Produtos</h1>
                    </div>
                    <div class="col-sm-4">
                        <button class="btn btn-primary" data-toggle="modal" data-target="#modalCadastro" onclick=location.href="<?=URL?>produtos">&laquo; Voltar</button>
                    </div>
                    <div class="col-sm-4">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="<?=URL?>">Home</a></li>
                            <li class="breadcrumb-item">Cadastros</li>
                            <li class="breadcrumb-item active"><a href="<?=URL?>produtos">Produtos</a></li>
                        </ol>
                    </div>
                </div>
            </div><!-- /.container-fluid -->
        </section>
<div class="modal-content">
<div class="modal-header">
    <h5 class="modal-title" id="exampleModalLabel">Visualização de Produto</h5>
</div>
<form  method="post" action="" enctype="multipart/form-data">
    <button class="btn btn-primary" onclick="abreVisualizaProdutos('dadosVisualizaProduto'); return false;">Dados do Produto</button>
    <button class="btn btn-success" onclick="abreVisualizaProdutos('itensVisualizaProduto'); return false;">Ítens do Produto</button>
    <div class="modal-body" id="dadosVisualizaProduto">
        <label for="nome">Nome: </label> <?=$row->nome?><br>
        <label for="nome">SKU: </label> <?=$row->sku?><br>
        <label for="descricao">Descrição:</label><?=$row->descricao?><br>
        <?php 
        $i = 1;
        foreach ($produtos_variacoes as $key => $value){
            ?><label for='variacao<?=$i?>'>Variação <?=$i?>:</label> <?=$value->nome?><br><?php
            $i++;
        }
        if (file_exists(DIRETORIO."img/produtos/".$row->id."/produto.jpg")){
            $img = URL."img/produtos/".$row->id."/produto.jpg";
        } elseif (file_exists(DIRETORIO."img/produtos/".$row->id."/produto.jpeg")){
            $img = URL."img/produtos/".$row->id."/produto.jpeg";
        } elseif (file_exists(DIRETORIO."img/produtos/".$row->id."/produto.gif")){
            $img = URL."img/produtos/".$row->id."/produto.gif";
        } elseif (file_exists(DIRETORIO."img/produtos/".$row->id."/produto.png")){
            $img = URL."img/produtos/".$row->id."/produto.png";
        } elseif (file_exists(DIRETORIO."img/produtos/".$row->id."/produto.bmp")){
            $img = URL."img/produtos/".$row->id."/produto.bmp";
        } elseif (file_exists(DIRETORIO."img/produtos/".$row->id."/produto.svg")){
            $img = URL."img/produtos/".$row->id."/produto.svg";
        } elseif (file_exists(DIRETORIO."img/produtos/".$row->id."/produto.webp")){
            $img = URL."img/produtos/".$row->id."/produto.webp";
        } else{
            $img = URL."img/noFoto1.gif";
        }
        ?>
        <label for="imagem">Imagem: </label> <img src="<?=$img?>" width="300"> <button type="button" class="btn btn-danger" onclick="excluirImagemProduto('<?=$row->id?>', '<?=URL?>')">Excluir Imagem</button><br>
    </div>
    <div id="itensVisualizaProduto" style="display:none">
        <?php $sql = "SELECT a.*, b.nome AS nomeTipoVariacao1, c.nome AS nomeTipoVariacao2 FROM produtos_itens a LEFT JOIN variacoes b ON (a.idTipoVariacao1 = b.id) LEFT JOIN variacoes c ON (a.idTipoVariacao2 = c.id) WHERE a.idProduto = '".$row->id."'";
        $query3 = mysqli_query($con, $sql);
        if (mysqli_num_rows($query3)){
            $i = 1;
            while ($row3 = mysqli_fetch_object($query3)){
                ?><h3>Ítem <?=$i?></h3>
                <?php if ($row3->idTipoVariacao1){?>
                    <label for="idTipoAtributo1"><?=$produtos_variacoes[0]->nome?>: </label> <?=$row3->nomeTipoVariacao1?><br>
                <?php }
                if ($row3->idTipoVariacao2){?>
                    <label for="idTipoAtributo2"><?=$produtos_variacoes[1]->nome?>: </label> <?=$row3->nomeTipoVariacao2?><br>
                <?php } ?>
                <label for="nomeItem">Nome: </label> <?=$row3->nome?><br>
                <?php if ($row3->descricao){?>
                    <label for="descricaoItem">Descrição: </label> <?=$row3->descricao?><?php
                }?>                
                <label for="valorItem">Valor: </label> R$<?=number_format($row3->valor, 2, ',', '.')?><br><?php
                if ($row3->promocao != '0'){?>
                    <label for="promocaoItem">Promoção: </label> R$<?=number_format($row3->promocao, 2, ',', '.')?><br><?php
                }
                if ($row3->validadePromocao){
                    $vet = explode('-', $row3->validadePromocao);
                    $row3->validadePromocao = $vet[2]."/".$vet[1]."/".$vet[0];?>
                    <label for="promocaoItem">Validade Promoção: </label> <?=$row3->validadePromocao?><br><?php
                }?>                
                <label for="estoqueItem">Estoque: </label> <?=$row3->estoque?><br><?php
                $i++;
            }
        }
        else{
            ?><div style="padding:15px; text-align:center"><div class="btn btn-danger">Sem informações cadastradas!</div></div><?php
        }?>
    </div>
    <div class="modal-footer">
        <button type="button" class="btn btn-secondary" onclick="location.href='<?=URL?>produtos'">&laquo; Voltar</button>
    </div>
</form>
</div>
</div>
</div>
<?php
    }
}
else{
    ?>
<div class="content-wrapper">
        <section class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-4">
                        <h1>Produtos</h1>
                    </div>
                    <div class="col-sm-4">
                        <button class="btn btn-primary" onclick=location.href="<?=URL?>produtos/cadastrar">Criar Novo</button>
                        <button class="btn btn-success" onclick=location.href="<?=URL?>produtos/importar">Importar CSV</button>
                        <button class="btn btn-info" onclick=location.href="<?=URL?>paginas/exportarProdutos.php?nomeFiltro=<?=$_REQUEST['nomeFiltro']?>">Exportar CSV</button>
                    </div>
                    <div class="col-sm-4">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="<?=URL?>">Home</a></li>
                            <li class="breadcrumb-item">Cadastros</li>
                            <li class="breadcrumb-item active"><a href="<?=URL?>produtos">Produtos</a></li>
                        </ol>
                    </div>
                </div>
            </div><!-- /.container-fluid -->
        </section>
<div class="my-3 p-3 bg-white rounded shadow-sm">
    <div class="media text-muted pt-3">
        <h6 style="cursor: pointer" onclick="abreFecha('filtro')">Filtro</h6>
    </div>
    <div class="media text-muted pt-3" id="filtro" style="display:none">
    <form name="filtro" action="" method="post">
        <div style="width:100%">
            <label for="nomeFiltro">Por Nome <span title="Buscando por aqui você filtra o resultrado por qualquer um dos campos pesquisandos da tabela!">*</span>: </label>
            <input type="text" class="form-control" id="nomeFiltro" name="nomeFiltro" style="width:100%" value="<?=$_REQUEST['nomeFiltro']?>">
        </div>
        <button type="submit" class="btn btn-primary">Filtrar</button>
    </div>
    </form>
    
    <div class="media text-muted pt-3" id="conteudo">
        <?php if ($produtos){?>
        <table id="example2" class="table table-bordered table-hover">
            <thead>
                <tr>
                    <th style="padding:5px">ID</th>
                    <th style="padding:5px">SKU</th>
                    <th style="padding:5px">Nome</th>
                    <th style="padding:5px">Valor</th>
                    <th style="padding:5px">Estoque</th>
                    <th style="padding:5px">Ações</th>
                </tr>
            </thead>
            <tbody>
            <?php foreach ($produtos as $key => $value){?>
                <tr>
                    <td style="padding:5px"><?=$value->id?></td>
                    <td style="padding:5px"><?=$value->sku?></td>
                    <td style="padding:5px"><?=$value->nome?></td>
                    <td style="padding:5px">R$<?php 
                    if ($value->promocao && $value->validadePromocao >= date('Y-m-d')){
                        echo number_format($value->promocao, 2, ',', '.');
                    }
                    else{
                        echo number_format($value->valor, 2, ',', '.');
                    }?></td>
                    <td style="padding:5px"><?=$value->estoque?></td>
                    <td style="padding:5px">
                         <a href="<?=URL?>produtos/visuailzar/<?=$value->id?>"><img src="<?=URL?>img/visualizar.svg" width="20"></a>
                         <a href="<?=URL?>produtos/editar/<?=$value->id?>"><img src="<?=URL?>img/editar.png" width="20"></a>
                        <a style="cursor:pointer" onclick=excluirProduto("<?=$value->id?>","<?=URL?>")><img src="<?=URL?>img/excluir.png" width="20"></a>
                    </td>

                </tr>
            <?php }?>
            </tbody>
        </table>
        <?php } else{ ?><div style="text-align:center; width:100%"><div class="btn btn-danger">Sem nenhum produto encontrado!</div></div><?php
        }?>
    </div>
</div>
    </div>
    <?php }?>