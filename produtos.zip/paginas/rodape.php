    <!-- /.content-wrapper -->
    <footer class="main-footer">
        <strong>&copy; <?=date('Y')?></strong>
        Todos os direitos reservados.
    </footer>

    <!-- Control Sidebar -->
    <aside class="control-sidebar control-sidebar-dark">
        <!-- Control sidebar content goes here -->
    </aside>
    <!-- /.control-sidebar -->
</div>
<!-- jQuery -->
<script src="<?=URL?>plugins/jquery/jquery.min.js"></script>
<!-- jQuery UI 1.11.4 -->
<script src="<?=URL?>plugins/jquery-ui/jquery-ui.min.js"></script>
<!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->
<script>
    $.widget.bridge('uibutton', $.ui.button)
</script>
<!-- Bootstrap 4 -->
<script src="<?=URL?>plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- ChartJS -->
<script src="<?=URL?>plugins/chart.js/Chart.min.js"></script>
<!-- AdminLTE App -->
<script src="<?=URL?>dist/js/adminlte.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="<?=URL?>dist/js/demo.js"></script>
<script src="<?=URL?>dist/js/scripts.js"></script>
<script src="<?=URL?>ckeditor/ckeditor.js"></script>
<script>CKEDITOR.replace('descricao');</script>
</body>
</html>