function abreFecha(id) {
    if(document.getElementById(id).style.display == ''){
        $("#"+id).hide('fast');
    }
    else{
        $("#"+id).show('slow');
    }
}

function excluirUsuario(id, url){
    if (confirm('Tem certeza que deseja excluir esse usuário?')){
        location.href=url+"admin/usuario/excluir/"+id;
    }
}
