<?php
$sql = "SELECT a.*, b.nome AS nomePai FROM variacoes a LEFT JOIN variacoes b ON (a.idPai = b.id)";
if ($_REQUEST['nomeFiltro']){
    $sql .= " WHERE a.nome LIKE '%".$_REQUEST['nomeFiltro']."%' OR b.nome LIKE '%".$_REQUEST['nomeFiltro']."%'";
    $where = 1;
}
$query = mysqli_query($con, $sql);
if (mysqli_num_rows($query)){
    while ($row = mysqli_fetch_object($query)){
        $variacao[] = $row;
    }
}
$sql = "SELECT a.*, b.valor, b.promocao, b.validadePromocao, b.estoque FROM produtos a LEFT JOIN produtos_itens b ON (a.id = b.idProduto)";
if ($_REQUEST['nomeFiltro']){
    $sql .= " WHERE a.nome LIKE '%".$_REQUEST['nomeFiltro']."%' OR a.descricao LIKE '%".$_REQUEST['nomeFiltro']."%' OR a.sku LIKE '%".$_REQUEST['nomeFiltro']."%' OR a.id LIKE '%".$_REQUEST['nomeFiltro']."%' OR b.valor LIKE '%".$_REQUEST['nomeFiltro']."%' OR b.promocao LIKE '%".$_REQUEST['nomeFiltro']."%'";
}
$sql .= " GROUP BY a.id";
$query = mysqli_query($con, $sql);
if (mysqli_num_rows($query)){
    while ($row = mysqli_fetch_object($query)){
        $produtos[] = $row;
    }
}
?>