/*
Navicat MySQL Data Transfer

Source Server         : localhost
Source Server Version : 50505
Source Host           : localhost:3306
Source Database       : produtos

Target Server Type    : MYSQL
Target Server Version : 50505
File Encoding         : 65001

Date: 2022-04-08 13:10:32
*/

SET FOREIGN_KEY_CHECKS=0;
-- ----------------------------
-- Table structure for `produtos`
-- ----------------------------
DROP TABLE IF EXISTS `produtos`;
CREATE TABLE `produtos` (
  `id` bigint(30) NOT NULL AUTO_INCREMENT,
  `nome` varchar(255) DEFAULT NULL,
  `sku` varchar(255) NOT NULL,
  `descricao` text DEFAULT '',
  PRIMARY KEY (`id`,`sku`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4;

-- ----------------------------
-- Records of produtos
-- ----------------------------
INSERT INTO `produtos` VALUES ('1', 'Produto Téste', '123456789', '<h1>Produto T&eacute;ste</h1>\r\n');
INSERT INTO `produtos` VALUES ('2', 'Produto Téste 2', '123456788', '');
INSERT INTO `produtos` VALUES ('3', 'Produto Téste 3', '123456787', '');
INSERT INTO `produtos` VALUES ('4', 'Produto Téste 4', '123456786', '');

-- ----------------------------
-- Table structure for `produtos_itens`
-- ----------------------------
DROP TABLE IF EXISTS `produtos_itens`;
CREATE TABLE `produtos_itens` (
  `id` bigint(30) NOT NULL AUTO_INCREMENT,
  `idProduto` bigint(30) NOT NULL,
  `idTipoVariacao1` bigint(30) DEFAULT NULL,
  `idTipoVariacao2` bigint(30) DEFAULT NULL,
  `nome` varchar(255) DEFAULT '',
  `estoque` bigint(30) DEFAULT NULL,
  `descricao` text DEFAULT NULL,
  `valor` decimal(10,2) DEFAULT NULL,
  `promocao` decimal(10,2) DEFAULT NULL,
  `validadePromocao` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4;

-- ----------------------------
-- Records of produtos_itens
-- ----------------------------
INSERT INTO `produtos_itens` VALUES ('1', '1', '3', '5', 'Téste', '999999', '<h1>T&eacute;ste</h1>\r\n', '129.90', '99.80', '9999-12-31');
INSERT INTO `produtos_itens` VALUES ('2', '1', '3', '6', 'Téste 2', '999999', '<h2>T&eacute;ste 2</h2>\r\n', '129.90', '99.80', '9999-12-31');
INSERT INTO `produtos_itens` VALUES ('3', '1', '4', '5', 'Téste 3', '999999', '<p>Teste 3</p>\r\n', '129.90', '99.80', '9999-12-31');
INSERT INTO `produtos_itens` VALUES ('4', '1', '4', '6', 'Téste 4', '999999', '<p>T&eacute;ste 4</p>\r\n', '129.90', '99.80', '9999-12-31');
INSERT INTO `produtos_itens` VALUES ('5', '2', '3', '0', 'Téste', '999999', '<h1>T&eacute;ste</h1>\r\n', '200.00', '150.00', '9999-12-31');
INSERT INTO `produtos_itens` VALUES ('6', '2', '4', '0', 'Téste 2', '999999', '<h2>T&eacute;ste 2</h2>\r\n', '200.00', '150.00', '9999-12-31');
INSERT INTO `produtos_itens` VALUES ('7', '3', '5', '0', 'Téste', '999999', '', '189.90', '175.00', '9999-12-31');
INSERT INTO `produtos_itens` VALUES ('8', '3', '6', '0', 'Téste 2', '999999', '<h2>T&eacute;ste 2</h2>\r\n', '189.90', '175.00', '9999-12-31');
INSERT INTO `produtos_itens` VALUES ('9', '4', '0', '0', 'Téste', '999999', '<h1>T&eacute;ste</h1>\r\n', '99.00', '75.00', '9999-12-31');

-- ----------------------------
-- Table structure for `produtos_variacoes`
-- ----------------------------
DROP TABLE IF EXISTS `produtos_variacoes`;
CREATE TABLE `produtos_variacoes` (
  `id` bigint(30) NOT NULL AUTO_INCREMENT,
  `idProduto` bigint(30) NOT NULL,
  `idVariacao` bigint(30) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=47 DEFAULT CHARSET=utf8mb4;

-- ----------------------------
-- Records of produtos_variacoes
-- ----------------------------
INSERT INTO `produtos_variacoes` VALUES ('43', '1', '1');
INSERT INTO `produtos_variacoes` VALUES ('44', '1', '2');
INSERT INTO `produtos_variacoes` VALUES ('45', '2', '1');
INSERT INTO `produtos_variacoes` VALUES ('46', '3', '2');

-- ----------------------------
-- Table structure for `variacoes`
-- ----------------------------
DROP TABLE IF EXISTS `variacoes`;
CREATE TABLE `variacoes` (
  `id` bigint(30) NOT NULL AUTO_INCREMENT,
  `idPai` bigint(30) DEFAULT NULL,
  `nome` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4;

-- ----------------------------
-- Records of variacoes
-- ----------------------------
INSERT INTO `variacoes` VALUES ('1', '0', 'Cor');
INSERT INTO `variacoes` VALUES ('2', '0', 'Tamanho');
INSERT INTO `variacoes` VALUES ('3', '1', 'Vermelho');
INSERT INTO `variacoes` VALUES ('4', '1', 'Preto');
INSERT INTO `variacoes` VALUES ('5', '2', '40');
INSERT INTO `variacoes` VALUES ('6', '2', '41');
