/*
Navicat MySQL Data Transfer

Source Server         : localhost
Source Server Version : 50505
Source Host           : localhost:3306
Source Database       : produtos

Target Server Type    : MYSQL
Target Server Version : 50505
File Encoding         : 65001

Date: 2022-04-09 15:52:27
*/

SET FOREIGN_KEY_CHECKS=0;
-- ----------------------------
-- Table structure for `produtos`
-- ----------------------------
DROP TABLE IF EXISTS `produtos`;
CREATE TABLE `produtos` (
  `id` bigint(30) NOT NULL AUTO_INCREMENT,
  `nome` varchar(255) DEFAULT NULL,
  `sku` varchar(255) NOT NULL,
  `descricao` text DEFAULT '',
  PRIMARY KEY (`id`,`sku`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4;

-- ----------------------------
-- Records of produtos
-- ----------------------------
INSERT INTO `produtos` VALUES ('1', 'Produto Téste', '123451', '');
INSERT INTO `produtos` VALUES ('2', 'Produto Téste 2', '123452', '');
INSERT INTO `produtos` VALUES ('3', 'Produto Téste 3', '123453', '');
INSERT INTO `produtos` VALUES ('4', 'Produto Teste Sem Foto', '123454', '');

-- ----------------------------
-- Table structure for `produtos_itens`
-- ----------------------------
DROP TABLE IF EXISTS `produtos_itens`;
CREATE TABLE `produtos_itens` (
  `id` bigint(30) NOT NULL AUTO_INCREMENT,
  `idProduto` bigint(30) NOT NULL,
  `idTipoVariacao1` bigint(30) DEFAULT NULL,
  `idTipoVariacao2` bigint(30) DEFAULT NULL,
  `nome` varchar(255) DEFAULT '',
  `estoque` bigint(30) DEFAULT NULL,
  `descricao` text DEFAULT NULL,
  `valor` decimal(10,2) DEFAULT NULL,
  `promocao` decimal(10,2) DEFAULT NULL,
  `validadePromocao` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4;

-- ----------------------------
-- Records of produtos_itens
-- ----------------------------
INSERT INTO `produtos_itens` VALUES ('1', '1', '3', '4', 'Vermelho - 40', '999999', null, '250.00', '100.00', '9999-12-31');
INSERT INTO `produtos_itens` VALUES ('2', '1', '3', '5', 'Vermelho - 41', '999999', null, '250.00', '100.00', '9999-12-31');
INSERT INTO `produtos_itens` VALUES ('3', '1', '6', '4', 'Preto - 40', '999999', null, '250.00', '150.00', '9999-12-31');
INSERT INTO `produtos_itens` VALUES ('4', '2', '3', '0', 'Vermelho', '999999', null, '2200.00', '2000.00', '9999-12-31');
INSERT INTO `produtos_itens` VALUES ('5', '2', '6', '0', 'Preto', '999999', null, '2200.00', '2000.00', '9999-12-31');
INSERT INTO `produtos_itens` VALUES ('6', '3', '4', '0', '40', '999999', null, '3700.00', '3000.00', '9999-12-31');
INSERT INTO `produtos_itens` VALUES ('7', '3', '5', '0', '41', '999999', null, '3700.00', '3000.00', '9999-12-31');
INSERT INTO `produtos_itens` VALUES ('8', '4', '0', '0', 'Téste', '999999', null, '399.00', '299.00', '9999-12-31');
INSERT INTO `produtos_itens` VALUES ('9', '1', '6', '5', 'Preto - 41', '999999', null, '250.00', '150.00', '9999-12-31');

-- ----------------------------
-- Table structure for `produtos_variacoes`
-- ----------------------------
DROP TABLE IF EXISTS `produtos_variacoes`;
CREATE TABLE `produtos_variacoes` (
  `id` bigint(30) NOT NULL AUTO_INCREMENT,
  `idProduto` bigint(30) NOT NULL,
  `idVariacao` bigint(30) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4;

-- ----------------------------
-- Records of produtos_variacoes
-- ----------------------------
INSERT INTO `produtos_variacoes` VALUES ('1', '1', '1');
INSERT INTO `produtos_variacoes` VALUES ('2', '1', '2');
INSERT INTO `produtos_variacoes` VALUES ('3', '2', '1');
INSERT INTO `produtos_variacoes` VALUES ('4', '3', '2');

-- ----------------------------
-- Table structure for `variacoes`
-- ----------------------------
DROP TABLE IF EXISTS `variacoes`;
CREATE TABLE `variacoes` (
  `id` bigint(30) NOT NULL AUTO_INCREMENT,
  `idPai` bigint(30) DEFAULT NULL,
  `nome` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4;

-- ----------------------------
-- Records of variacoes
-- ----------------------------
INSERT INTO `variacoes` VALUES ('1', '0', 'Cor');
INSERT INTO `variacoes` VALUES ('2', '0', 'Tamanho');
INSERT INTO `variacoes` VALUES ('3', '1', 'Vermelho');
INSERT INTO `variacoes` VALUES ('4', '2', '40');
INSERT INTO `variacoes` VALUES ('5', '2', '41');
INSERT INTO `variacoes` VALUES ('6', '1', 'Preto');
