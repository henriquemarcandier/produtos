<?php 
error_reporting(1);
ini_set('display_erros', 'on');
@session_start();
$url = $_SERVER['REQUEST_URI'];
$vet = explode("/", $url);
array_shift($vet);
if ($_SERVER['HTTP_HOST'] == 'localhost'){
    array_shift($vet);
    $exp = explode('?', $vet[0]);
    $vet[0] = $exp[0];
    $link = "https://localhost/teste/";
}
if($vet[0]){
    $link .= $vet[0]."/";
}
if ($vet[1]){
    $link .= $vet[1]."/";
}
if ($vet[2]){
    $link .= $vet[2]."/";
}
if (!$_SERVER['HTTPS']){
    header('location: '.$link);
}
$param = $vet[0];
// incluo o arquivo de conexão com o bd
require_once('connect.php');
// incluo o arquivo que faz todos os sql de listagem do sistema
require_once('pegaSqls.php');
// incluo o arquivo do cabeçalho do sistema
require_once("paginas/cabecalho.php");
// abaixo eu verifica qual a página a ser exibida de acordo com o que está na url
if ($param == "" || $param == 'home'){
    require_once("paginas/index.php");
}
elseif ($param == 'variacao'){
    require_once("paginas/variacao.php");
}
elseif ($param == 'produtos'){
    require_once("paginas/produtos.php");
}
elseif ($param == 'limparTodasTabelas'){
    require_once("paginas/limparTodasTabelas.php");
}
require_once("paginas/rodape.php");
?>