<?php
ini_set('display_errors', 'off');
@session_start();
date_default_timezone_set("America/Sao_Paulo");
setlocale(LC_ALL, 'pt_BR');
$url = "https://localhost/produtos/";
$diretorio = "D:/xampp2/htdocs/produtos/";
$dbhost = "localhost";
$dbuser = "root";
$dbpass = "";
$dbname = "produtos";
$con = mysqli_connect($dbhost, $dbuser, $dbpass, $dbname) or die(mysqli_error($con));
define("URL", $url);
define("URL_SITE", $url_site);
define("DIRETORIO_SITE", $diretorio_site);
define("DIRETORIO", $diretorio);
?>
